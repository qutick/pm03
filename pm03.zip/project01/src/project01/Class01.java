package project01;

public class Class01 {

	public static void main(String[] args) {
		System.out.println("Хасанов Фридун");
		System.out.println("Х");
		System.out.println("а");
		System.out.println("с");
		System.out.println("а");
		System.out.println("н");
		System.out.println("о");
		System.out.println("в");
		int age = 19;
		System.out.println("Фарид "+ age );
	}

}
